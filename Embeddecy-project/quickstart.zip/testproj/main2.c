#include <stm32f30x.h>
#include <stm32f30x_rcc.h>
#include <stm32f30x_gpio.h>
#include <FreeRTOSConfig.h>
#include "include/FreeRTOS.h"
#include "include/task.h"
#include "include/queue.h"

#define LEDS (GPIO_Pin_8 | GPIO_Pin_9)

void vTask1(void *pvParameters) {
	for (;;) {
		GPIO_SetBits(GPIOE, GPIO_Pin_8);
		vTaskDelay(200);
		GPIO_ResetBits(GPIOE, GPIO_Pin_8);
		vTaskDelay(200);
	}
}
void vTask2(void *pvParameters) {
	for (;;) {
		GPIO_SetBits(GPIOE, GPIO_Pin_9);
		vTaskDelay(200);
		GPIO_ResetBits(GPIOE, GPIO_Pin_9);
		vTaskDelay(200);
	}
}

void vApplicationTickHook(void) {
}
int main2() {
	GPIO_InitTypeDef gpio;
// Blue LED is connected to port E, pin 8 (AHB bus)
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOE, ENABLE);

// Configure port E (LED)
	GPIO_StructInit(&gpio);
	gpio.GPIO_Mode = GPIO_Mode_OUT;
	gpio.GPIO_Pin = LEDS;
	GPIO_Init(GPIOE, &gpio);

	xTaskCreate(vTask1, (signed char *) "LED1", configMINIMAL_STACK_SIZE, NULL,
			2,NULL);
	xTaskCreate(vTask2, (signed char *) "LED2", configMINIMAL_STACK_SIZE, NULL,
			2,NULL);

	vTaskStartScheduler();
// Blinking LEDS
	while (1) {
	}
}
